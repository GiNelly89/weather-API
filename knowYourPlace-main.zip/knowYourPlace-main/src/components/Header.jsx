import React from "react";

const Header = () => {
  return (
    <>
      <img src="" alt="" />
      <h1 className="font-black dark:text-white text-4xl text-center p-5">
        Know your Place!
      </h1>
    </>
  );
};

export default Header;
